# Projeto IWGD

Ideia: Forum :)

## Features

* Threads
* follow ups
* Users
* Tipos de users (admins, mods, Verified (tipo super), normais)
* Login, Register, Logout, acesso sem login
* Pagina principal
* Pesquisa (fulltext , regex??????)
* Profile (com os threads criaods  e participados)
* Stalk (ou seja ver os posts das pessoas)
* REport, remove users
* users coments
* QUoets, data de quando publicado
* Remover, editar 
* Signiature-like
* foto de perfil + bio
* Titulo do thread
* markdown-like post
* sort thread (new, old, most quoted, user)
* filter (users, palavras no thread)
* followers????? (prob not)
* Rss
* pagination
* Video embed option
* Preview post system
* rascunho?
* favourite foruns per user

## Coisas que falta
* search redisign
* welcome mais pra baixo (centrado ou em baixo)
* clicar no nome vai pro perfil
* pagina de perfil
* avatar
* signature (Eu)
* background partido
* pin (Eu)
* caixa de texto para texto (Eu) no comment e new thread
* fazer posts pra todos
* admin page
* admin page take action (eu)
* follow ups (eu)
* reply (eu)
* customizado (eu)
* stalk maybe (eu)
* promover mod
* stickies falta o simboolo (eu)
* link pro usuario
* traduzir td para pt
* paginacao maybe
* pesquisa transformacao
* apagar testar
* bookmars maybe (eu)
* relatorio (eu)
* QUANDO DELETE MOSTRAR Q ALGUMA COISA FOI DELETADA (eu)
* mudar logo para wip (eu)
* report popup ta broken
* Nao esquecer de ver TODOs
* favicon